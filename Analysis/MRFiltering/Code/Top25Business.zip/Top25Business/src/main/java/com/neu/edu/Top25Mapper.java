package com.neu.edu;

import java.io.IOException;
import java.util.TreeMap;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Top25Mapper extends Mapper<Object, Text, NullWritable, Text>{

	private TreeMap<Integer,Text>  tm = new TreeMap<Integer, Text>();
	
	@Override
	protected void map(Object key, Text value, Mapper<Object, Text, NullWritable, Text>.Context context)
			throws IOException, InterruptedException {
		
		String input[] = value.toString().split("\t");
		try {
			String business = input[0];
			int noOfRating = Integer.parseInt(input[1]);
			tm.put(noOfRating, new Text(value));
				
			if(tm.size()>25) {
				tm.remove(tm.firstKey());
			}
			
		}catch(Exception e) {
			
		}
	}
		

	@Override
	protected void cleanup(Mapper<Object, Text, NullWritable, Text>.Context context)
			throws IOException, InterruptedException {
		
		for(Text t: tm.values()) {
			context.write(NullWritable.get(), t);
		}
	}
	
}
