package com.neu.edu;

import java.io.IOException;
import java.util.Map;
import java.util.TreeMap;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Top25Reducer extends Reducer<NullWritable, Text, NullWritable, Text>{
	
	private TreeMap<Integer, Text> tm = new TreeMap<Integer, Text>();
	
	@Override
	protected void reduce(NullWritable key, Iterable<Text> values, Reducer<NullWritable, Text, NullWritable, Text>.Context context) throws IOException, InterruptedException {
		
		
		for(Text value : values) {
			String input[] = value.toString().split("\t");
			int count = Integer.parseInt(input[1]);
			tm.put(count, new Text(value));
			if(tm.size()> 25) {
				tm.remove(tm.firstKey());
			}
		}
	}

	@Override
	protected void cleanup(Reducer<NullWritable, Text, NullWritable, Text>.Context context)
			throws IOException, InterruptedException {
		for(Text t : tm.descendingMap().values()) {
			context.write(NullWritable.get(), t);
		}
	}
}
