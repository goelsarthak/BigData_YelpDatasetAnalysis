package com.neu.edu;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.input.TextInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.mapreduce.lib.output.TextOutputFormat;

public class DriverClass {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Configuration conf = new Configuration();
		Job job = Job.getInstance(conf, "Top25Business");
	    job.setJarByClass(DriverClass.class);
		
		FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        
        job.setInputFormatClass(TextInputFormat.class);
	    job.setOutputFormatClass(TextOutputFormat.class);
	    job.setMapOutputKeyClass(Text.class);
	    job.setMapOutputValueClass(IntWritable.class);
        
        
        job.setMapperClass(Mapper1.class);
        job.setReducerClass(Reducer1.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        
		
	    boolean result = job.waitForCompletion(true);
	    
	    if(result) {
	    	Job job1 = Job.getInstance(conf, "Top25Business");
	    	job1.setJarByClass(DriverClass.class);
	    	
	    	job1.setInputFormatClass(TextInputFormat.class);
		     job1.setOutputFormatClass(TextOutputFormat.class);
	    	
	        job1.setMapperClass(Top25Mapper.class);
	        job1.setReducerClass(Top25Reducer.class);
	        
	        job1.setOutputKeyClass(NullWritable.class);
		    job1.setOutputValueClass(Text.class);
	  		
	        FileInputFormat.addInputPath(job1, new Path(args[1]));
	        FileOutputFormat.setOutputPath(job1, new Path(args[2]));
	        
	        result = job1.waitForCompletion(true);
	    }
	}	
}
