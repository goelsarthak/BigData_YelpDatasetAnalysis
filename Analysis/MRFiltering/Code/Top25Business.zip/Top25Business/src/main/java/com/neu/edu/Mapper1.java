package com.neu.edu;

import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper1 extends Mapper<Object, Text, Text, IntWritable>{

	Text outKey = new Text();
	IntWritable outVal = new IntWritable(); 
	
	@Override
	protected void map(Object key, Text value, Mapper<Object, Text, Text, IntWritable>.Context context)
			throws IOException, InterruptedException {
		
		try {
		String input[] = value.toString().split("\t");
		outKey.set(input[2]);
		outVal.set(1);
		context.write(outKey, outVal);
		} catch(Exception e) {
			
		}
	}
}
