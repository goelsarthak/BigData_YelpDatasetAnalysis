package com.neu.edu;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.mapreduce.Partitioner;

public class PartitionerClass extends Partitioner<CompositeKeyClass, FloatWritable> {

	@Override
	public int getPartition(CompositeKeyClass key, FloatWritable text, int numberOfPartitions) {
		// TODO Auto-generated method stub
		return Math.abs(key.getBusinessYear().hashCode() % numberOfPartitions);
	}

}
