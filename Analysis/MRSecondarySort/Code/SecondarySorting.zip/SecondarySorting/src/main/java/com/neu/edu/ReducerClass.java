package com.neu.edu;

import java.io.IOException;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class ReducerClass extends Reducer<CompositeKeyClass, FloatWritable, CompositeKeyClass, Text> {

	Text outVal = new Text();
	
	@Override
	protected void reduce(CompositeKeyClass key, Iterable<FloatWritable> values,
			Reducer<CompositeKeyClass, FloatWritable, CompositeKeyClass, Text>.Context context)
			throws IOException, InterruptedException {
		
		StringBuilder sortedRating = new StringBuilder();
		for(FloatWritable val : values){
			sortedRating.append(val.get());
			sortedRating.append(",");
		}
		outVal.set(sortedRating.toString());
		context.write(key,outVal);
	}
}
