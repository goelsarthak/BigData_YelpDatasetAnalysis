package com.neu.edu;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.io.WritableComparable;

public class CompositeKeyClass implements Writable, WritableComparable<CompositeKeyClass>{

	private String businessYear;
	private Float rating;
	
	public String getBusinessYear() {
		return businessYear;
	}

	public void setBusinessYear(String businessYear) {
		this.businessYear = businessYear;
	}

	public Float getRating() {
		return rating;
	}

	public void setRating(Float rating) {
		this.rating = rating;
	}

	public void readFields(DataInput in) throws IOException {
		businessYear = in.readUTF();
		rating = in.readFloat();
	}

	public void write(DataOutput out) throws IOException {
		out.writeUTF(businessYear);
		out.writeFloat(rating);
	}

	public int compareTo(CompositeKeyClass o) {
		int result = this.businessYear.compareTo(o.getBusinessYear());
		if (result == 0) {
			return this.rating.compareTo(o.getRating());
		}
		return result;
	}
	
	@Override
	public String toString() {

		return businessYear;
	}
}
