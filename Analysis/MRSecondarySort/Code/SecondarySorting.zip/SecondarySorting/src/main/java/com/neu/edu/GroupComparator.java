package com.neu.edu;

import org.apache.hadoop.io.WritableComparator;

public class GroupComparator extends WritableComparator{

	protected GroupComparator() {
		super(CompositeKeyClass.class, true);
	}

	@Override
	public int compare(Object a, Object b) {
		
		CompositeKeyClass ckw1 = (CompositeKeyClass)a;
		CompositeKeyClass ckw2 = (CompositeKeyClass)b;
		
		return ckw1.getBusinessYear().compareTo(ckw2.getBusinessYear());
	}
	
}