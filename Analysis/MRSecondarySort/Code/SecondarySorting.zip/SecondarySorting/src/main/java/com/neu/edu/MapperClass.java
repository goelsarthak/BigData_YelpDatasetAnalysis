package com.neu.edu;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class MapperClass extends Mapper<Object, Text, CompositeKeyClass, FloatWritable>{

	private final static SimpleDateFormat frmt = new SimpleDateFormat("MM/DD/yy");
    private FloatWritable outVal = new FloatWritable();
	
	@Override
	protected void map(Object key, Text value, Mapper<Object, Text, CompositeKeyClass, FloatWritable>.Context context)
			throws IOException, InterruptedException {
		
		try {
			String input[] = value.toString().split("\t");
			if(input.length > 5) {
			
					Calendar cal = Calendar.getInstance();
					String strDate = input[4];
					String businessId = input[2];
					String ratings = input[3];
					try {
						cal.setTime(frmt.parse(strDate));
					} catch (ParseException e) {
					
					}
					
					String businessYear = businessId + " - " + String.valueOf(cal.get(Calendar.YEAR));
					CompositeKeyClass compKey = new CompositeKeyClass();
					compKey.setBusinessYear(businessYear);
					compKey.setRating(Float.parseFloat(ratings));
					outVal.set(Float.parseFloat(ratings));
				
					context.write(compKey, outVal);
				
			}
		} catch(Exception e) {
			
		}
	}
}