package com.neu.edu;

import org.apache.hadoop.io.WritableComparable;
import org.apache.hadoop.io.WritableComparator;

public class SecondarySortComparator extends WritableComparator {

	protected SecondarySortComparator() {
		super(CompositeKeyClass.class, true);
	}

	@Override
	public int compare(WritableComparable a, WritableComparable b) {

		CompositeKeyClass ckw1 = (CompositeKeyClass) a;
		CompositeKeyClass ckw2 = (CompositeKeyClass) b;

		int result = ckw1.getBusinessYear().compareTo(ckw2.getBusinessYear());

		if (result == 0) {
			return -ckw1.getRating().compareTo(ckw2.getRating());
		}

		return result;
	}
}
