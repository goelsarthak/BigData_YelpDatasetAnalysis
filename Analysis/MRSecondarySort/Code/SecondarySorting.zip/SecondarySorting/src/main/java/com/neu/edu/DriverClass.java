package com.neu.edu;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.FloatWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class DriverClass {

	public static void main( String[] args ) throws IOException, ClassNotFoundException, InterruptedException
    {
		Configuration conf = new Configuration();
		Job job = new Job(conf,"SecondarySort");
        job.setJarByClass(DriverClass.class);
        
        
        job.setMapperClass(MapperClass.class);
        job.setReducerClass(ReducerClass.class);
        job.setPartitionerClass(PartitionerClass.class);
        job.setGroupingComparatorClass(GroupComparator.class);
        job.setSortComparatorClass(SecondarySortComparator.class);
        
        job.setNumReduceTasks(1);
        
        FileInputFormat.addInputPath(job, new Path(args[0]));
        Path outDir = new Path(args[1]);
        FileOutputFormat.setOutputPath(job, outDir);
        
        job.setMapOutputKeyClass(CompositeKeyClass.class);
	    job.setMapOutputValueClass(FloatWritable.class);
        
        job.setOutputKeyClass(CompositeKeyClass.class);
        job.setOutputValueClass(Text.class);
        
        FileSystem fs = FileSystem.get(job.getConfiguration());
        if(fs.exists(outDir)) {
        	fs.delete(outDir, true);
        }
        job.getConfiguration().setStrings("mapreduce.reduce.shuffle.memory.limit.percent", "0.15");
        job.waitForCompletion(true);
    }
	
}
