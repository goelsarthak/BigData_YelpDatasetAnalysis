package com.neu.edu;

import java.io.IOException;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.NullWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;


public class DriverClass {

	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		
		Configuration conf = new Configuration();
	    Job job = new Job(conf, "MRchain");
	    job.setJarByClass(DriverClass.class);
		
		job.setPartitionerClass(Partitioner1.class);
		Partitioner1.setMinLastAccessDate(job, 2004);

		job.setNumReduceTasks(14);
		
		FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));
        
        job.setMapOutputKeyClass(IntWritable.class);
	    job.setMapOutputValueClass(Text.class);
        
        job.setMapperClass(Mapper1.class);
        job.setReducerClass(Reducer1.class);
        
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(NullWritable.class);
        
		
	    boolean result = job.waitForCompletion(true);
	    if(result) {
	    	Job job1 = Job.getInstance(conf, "chain");
	    	job1.setJarByClass(DriverClass.class);
	    	
	        job1.setMapperClass(Mapper2.class);
	        job1.setCombinerClass(Reducer2.class);
	        job1.setReducerClass(Reducer2.class);
	  		
	        job1.setOutputKeyClass(Text.class);
	        job1.setOutputValueClass(IntWritable.class);
	  		
	        FileInputFormat.addInputPath(job1, new Path(args[1]));
	        FileOutputFormat.setOutputPath(job1, new Path(args[2]));
	        
	        result = job1.waitForCompletion(true);
	    }
	}	
}
