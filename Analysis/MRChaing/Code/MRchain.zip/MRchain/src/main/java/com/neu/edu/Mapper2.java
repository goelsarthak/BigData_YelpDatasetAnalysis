package com.neu.edu;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper2 extends Mapper<Object, Text, Text, IntWritable>{

	private final static SimpleDateFormat frmt = new SimpleDateFormat("yyyy-MM-DD");
	private IntWritable outVal = new IntWritable();
    private Text outKey = new Text();
	
	@Override
	protected void map(Object key, Text value, Context context) throws IOException, InterruptedException {
		
		String input[] = value.toString().split(",",-1);
		if(input[3].length() == 10) {
			String strDate = input[3];
			Calendar cal = Calendar.getInstance();
        
			try {
				cal.setTime(frmt.parse(strDate));
			} catch (ParseException e) {
			
			}

			outKey.set(String.valueOf(cal.get(Calendar.YEAR)));
			outVal.set(1);
			
			context.write(outKey, outVal);
		}
	}
}
