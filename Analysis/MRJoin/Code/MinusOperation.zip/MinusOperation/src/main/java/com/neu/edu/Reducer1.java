package com.neu.edu;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

public class Reducer1 extends Reducer<Text, Text, Text, Text>{
    
private static final Text EMPTY_TEXT = new Text("");
private ArrayList<Text> listUsers = new ArrayList<Text>();
private ArrayList<Text> listReviews = new ArrayList<Text>();
private Text tmpVal = new Text();

private String joinType = null;

	public void setup(Reducer.Context context) {
		joinType = context.getConfiguration().get("join.type");
	}

	public void reduce(Text key, Iterable<Text> values, Context context) throws IOException, InterruptedException {
  
		listUsers.clear();
		listReviews.clear();
    
		while (values.iterator().hasNext()) {
			tmpVal = values.iterator().next();
        
			if (Character.toString((char) tmpVal.charAt(0)).equals("U")) {
				listUsers.add(new Text(tmpVal.toString().substring(1)));
			}
			
			if (Character.toString((char) tmpVal.charAt(0)).equals("R")) {
				listReviews.add(new Text(tmpVal.toString().substring(1)));
			}
		}
    minusLogic(context);
	}
	
	public void minusLogic(Context context) {
		if (joinType.equalsIgnoreCase("minus")) {
			for (Text usr : listUsers) {
				if(listReviews.isEmpty()) {
					try {
						context.write(usr, EMPTY_TEXT);
					} catch (Exception e) {
						
					} 
				}
            }
		}
	}
}
