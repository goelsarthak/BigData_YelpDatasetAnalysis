package com.neu.edu;

import java.io.IOException;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class Mapper2 extends Mapper<Object, Text, Text, Text>{
	
	public Text outKey = new Text();
    public Text outVal = new Text();
	
	@Override
	protected void map(Object key, Text value, Mapper<Object, Text, Text, Text>.Context context)
			throws IOException, InterruptedException {
		
		String[] input = value.toString().split(",",-1);
        String userId = input[1];
        
        if(userId!= null || !userId.isEmpty()) {
        	outKey.set(userId);
            outVal.set("R" + value.toString());
            context.write(outKey, outVal);
        }		
	}
}
