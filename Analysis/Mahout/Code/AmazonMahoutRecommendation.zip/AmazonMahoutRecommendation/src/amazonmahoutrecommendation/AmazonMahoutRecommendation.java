
package amazonmahoutrecommendation;

import java.io.File;
import java.io.IOException;
import java.util.List;
import org.apache.mahout.cf.taste.common.TasteException;
import org.apache.mahout.cf.taste.impl.common.LongPrimitiveIterator;
import org.apache.mahout.cf.taste.impl.model.file.FileDataModel;
import org.apache.mahout.cf.taste.impl.neighborhood.ThresholdUserNeighborhood;
import org.apache.mahout.cf.taste.impl.recommender.GenericUserBasedRecommender;
import org.apache.mahout.cf.taste.impl.similarity.PearsonCorrelationSimilarity;
import org.apache.mahout.cf.taste.model.DataModel;
import org.apache.mahout.cf.taste.neighborhood.UserNeighborhood;
import org.apache.mahout.cf.taste.recommender.RecommendedItem;
import org.apache.mahout.cf.taste.recommender.Recommender;
import org.apache.mahout.cf.taste.similarity.UserSimilarity;

public class AmazonMahoutRecommendation {

    public static void main(String[] args) throws IOException, TasteException{
        
      File userPreferencesFile = new File("/Users/sarthakgoel/Desktop/Project/Analysis/Mahout/Input/MahoutInput.csv");
      DataModel dataModel = new FileDataModel(userPreferencesFile);
      
      UserSimilarity userSimilarity = new PearsonCorrelationSimilarity(dataModel);
      UserNeighborhood userNeighborhood = new ThresholdUserNeighborhood(0.1, userSimilarity, dataModel);
 
      Recommender genericRecommender =  new GenericUserBasedRecommender(dataModel, userNeighborhood, userSimilarity);
 
      for (LongPrimitiveIterator iterator = dataModel.getUserIDs(); iterator.hasNext();)
      {
          long userId = iterator.nextLong();
 
          List<RecommendedItem> itemRecommendations = genericRecommender.recommend(userId, 5);
 
          System.out.format("User Id: %d%n", userId);
 
          if (itemRecommendations.isEmpty())
          {
              System.out.println("No recommendations for this user.");
          }
          else
          {
              for (RecommendedItem recommendedItem : itemRecommendations)
              {
                  System.out.format("Recommened Item Id %d. Strength of the preference: %f%n", recommendedItem.getItemID(), recommendedItem.getValue());
              }
          }
      }
    }
}