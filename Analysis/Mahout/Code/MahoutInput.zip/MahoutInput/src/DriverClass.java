import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class DriverClass {

	
	static HashMap<String, Integer> um = new HashMap<String, Integer>();
	static HashMap<String, Integer> bm = new HashMap<String, Integer>();
	
	private static int getUser(String user)
	{
	    if (!um.containsKey(user))
	    	um.put(user, um.size() + 1);

	    return um.get(user);
	}
	
	private static int getBusiness(String business)
	{
	    if (!bm.containsKey(business))
	    	bm.put(business, bm.size() + 1);

	    return bm.get(business);
	}
	
	private static void saveMapping(HashMap<String, Integer> mapping, String fileName) throws IOException
	{
		int limitPrint = mapping.size(); 

		FileWriter fstream; 
		BufferedWriter out; 

		fstream = new FileWriter("/Users/sarthakgoel/Desktop/Project/Analysis/Mahout/Input/" + fileName); 
		out = new BufferedWriter(fstream);
		
		for (Map.Entry<String,Integer> entry : mapping.entrySet()) {
            //System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue()); 
            out.write(entry.getKey() + "\t");
            out.write(entry.getValue() + "\n");
		}

		out.close();
	
	}
	
	public static void mahoutInput() throws IOException {
		try {
		File file = new File("/Users/sarthakgoel/Desktop/Project/Analysis/Mahout/Input/InputFile.csv");
		FileWriter fstream = new FileWriter("/Users/sarthakgoel/Desktop/Project/Analysis/Mahout/Input/MahoutInput.csv");
		BufferedReader br = new BufferedReader(new FileReader(file));
		BufferedWriter out = new BufferedWriter(fstream);
		String st; 
		while ((st = br.readLine()) != null) { 
			if(!st.isEmpty()) {
				String input[] = st.split(",");
				int user = getUser(input[0]);
				int business = getBusiness(input[1]);
				String ratings = input[2];
				
				if(!String.valueOf(user).isEmpty() && !String.valueOf(business).isEmpty() && !ratings.isEmpty())
				out.write(String.valueOf(user));
				out.write(",");
				out.write(String.valueOf(business));
				out.write(",");
				out.write(ratings);
				out.write("\n");
			}
		}
		
		br.close();
		out.close();
		} catch(Exception e){
			
		}

		saveMapping(um, "usersMap.csv");
		saveMapping(bm, "businessMap.csv");
	}
	
	
	public static void main(String[] args) throws IOException {
		
		mahoutInput();
	}
}
